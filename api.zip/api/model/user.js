const mongoose = require('mongoose');
 const UserSchema = new mongoose.Schema(
	{
        userName: {
			type: String,
			lowercase: true,
			trim: true,
			index: true,
			unique: true,
			required: true
		},
		email: {
			type: String,
			lowercase: true,
			trim: true,
			index: true,
			unique: true,
			required: true
		}, 
		password: {
			type: String,
			required: true,
			bcrypt: true
		},
		name: {
			type: String,
			trim: true, 
		},		
		contact: {
			type: String,
			trim: true,
		},
		createdAt: { type: Date },
		updatedAt: { type: Date},
		
	},
	{ collection: 'USER' }
);

 
module.exports =  mongoose.model('USER', UserSchema);
