 
var mongoose = require('mongoose');
var config = require('../../config');
 console.log(config.database.uri)
const connection = mongoose.connect(config.database.uri || config.connectionString, { useUnifiedTopology: true, useNewUrlParser: true });
console.log(connection)
mongoose.Promise = global.Promise;
connection
	.then(db => {
		console.log('connected',`${config.database.uri}`)
		
		console.info(
			`Successfully connected to ${config.database.uri} MongoDB cluster in ${
				config.env
			} mode.`,
		);
		return db;
	})
	.catch(err => {
		console.log(err)
		if (err.message.code === 'ETIMEDOUT') {
			console.info('Attempting to re-establish database connection.');
			mongoose.connect(config.database.uri);
		} else {
			console.error('Error while attempting to connect to database:');
			
		}
	});

	module.exports = connection;
	 