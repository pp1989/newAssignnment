
const userSchema = require('../model/user')
const md5 = require('md5');
const response = require('../constants/responseCode');
const message = require('../constants/message');

const validateEmail = (email) => {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}


exports.getUserByEmail = async (email,userName) => {
    try {
        let user = await userSchema.findOne({
            $or: [{
                email: email.toLowerCase(),
            }, {
                userName: userName.toLowerCase(),
            }]

        });

        if (user) {
            return response.code200(user, message.EMAIL_ALREADY_EXIST);
        } else {
            return response.code200([], '');
        }
    } catch (err) {
        console.error(err)
    }
}


exports.insertUser = async ({ name, email, password, contact, userName }) => {
    try {
        let user = new userSchema();
        user.name = name;
        user.email = email;
        user.contact = contact;
        user.userName =userName;
        user.password = md5(`${password}`); 
        let result = await user.save();
        return response.code200(result, message.SUCCESSFULLY_CREATED);
    } catch (err) {
        console.error(err)
    }
}

exports.logIn = async (username, password) => {
    try {

        let checkEmail = validateEmail(username);
        if (checkEmail) {
            let res1 = await userSchema.findOne({
                email: username, 
                password: md5(`${password}`),
            })
            return res1;
        } else {
            let res = await userSchema.findOne({
                userName:  username.toLowerCase(),
                password: md5(`${password}`),
            })
            return res;
        }

    } catch (err) {
        console.error(err)
    }

}