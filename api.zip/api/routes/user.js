var express = require('express');
const { NotExtended } = require('http-errors');
var router = express.Router();
const UserController = require('../controllers/UserController');
const checkAuth = require('../middleware/CheckAuth');
// require('../../api/controllers/UserController')
/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });

router.post('/',  UserController.logIn);
router.post('/signup', UserController.SignUp);

module.exports = router;
