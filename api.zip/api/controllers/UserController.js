
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const jwt = require("jsonwebtoken");
const message = require('../constants/message');
const userSchema = require('../model/user')
const users = require('../supportiveFunction/Auth')
const response = require('../constants/responseCode');

exports.logIn = async (req, res) => {
    try {
      const { userNameOrEmail, password } = req.body;
      if (!userNameOrEmail || !password) {
        return res.send(response.code400(message.EMAIL_PASSWORD_BLANK));
      }
      let result = await users.logIn(userNameOrEmail, password);
      if (result === null) {
        return res.send(response.code404(message.INVALID_USERNAME_PASSWOROD))
      }
  
      if (result) {
  
        let { _id, email, userName,contact, name } = result;
        const token = await jwt.sign({
            _id,
            name,
            userName,
            contact,
            email
        },
          process.env.JWT_KEY,
          { expiresIn: 60*60*24*7 }
        );
  
       let userDetails = {
          _id,
          userName,
          email,
          name,
          contact,
          token,
        }
        return res.send(response.code200(userDetails, message.SUCCESS_LOGIN));
      } else {
        return res.send(result);
      }
    } catch (err) {
      console.error(err);
    }
  }

  exports.SignUp = async (req, res) => {
    try {
      const { name, email, password, contact, userName } = req.body;
      if (!name || !email || !password || !contact || !userName) {
        return res.send(message.EMAIL_NAME_PASSWROD_BLANK)
      }
      let getUser = await users.getUserByEmail(email,userName);
      if (getUser.statusCode === 200) {
        let saveUser = await users.insertUser(req.body);
        return res.send(saveUser);
      } else {
        return res.send(getUser);
      }
    } catch (err) {
      console.error(err);
    }
  
  }