require('dotenv').config({path:'./.env'})

module.exports= {
	env: process.env.NODE_ENV || 'development',
	database: {
		uri: process.env.DB, // DB  
	},

    path: {
		dev: process.env.DEV, // http://192.168.14.8/
		devApi: process.env.DEVAPI, //http://192.168.14.8:3000/api/  

		// prod: process.env.PROD, // http://192.168.14.8/
		// prodApi: process.env.PRODAPI, //http://192.168.14.8:3000/api/  

		// test: process.env.TEST, // http://localhost:3006/
		// testapi: process.env.TESTAPI, // http://localhost:3000/api/  
		
	},
}