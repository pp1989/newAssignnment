exports.code200 = (result, message,page=null) => {
    return {
        "success": true,
        "message": message,
        "statusCode": 200,
        "response": result
    }
}

exports.code401 = (message) => {
    return {
        "success": false,
        "message": message,
        "statusCode": 401,
        "response": []
    }
}

exports.code400 = (message) => {
    return {
        "success": false,
        "message": message,
        "statusCode": 400,
        "response": []
    }
}

exports.code404 = (message) => {
    return {
        "success": false,
        "message": message,
        "statusCode": 404,
        "response": []
    }
}
