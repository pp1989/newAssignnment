
module.exports ={
    "SUCCESSFULLY_CREATED": "Account created successfully",
    "EMAIL_PASSWORD_BLANK": "Email or password is blank",
    "INVALID_USERNAME_PASSWOROD": "Invalid username or password",
    "SUCCESS_LOGIN": "Successfully login",
    "ERROR": "Error! Please try again",
    "EMAIL_NAME_PASSWROD_BLANK": "Name, Email or Password is blank",
    "EMAIL_ALREADY_EXIST": "Email already exist",

}
