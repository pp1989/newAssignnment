import './App.css';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import Dashboard from './components/Dashboard'

function App() {
  return (
    <div className="App">
      <header className="App-header">

      <Router>
				<Routes>
					<Route exact path="/" element={<SignIn />} />
					<Route exact path="/signup" element={<SignUp />} />
          <Route exact path="/dashboard" element={<Dashboard />} />
          </Routes>
          </Router>
				
      </header>
    </div>
  );
}

export default App;
