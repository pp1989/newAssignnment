import React, { useState } from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import  commonservice  from '../commonServices';
import { useNavigate } from 'react-router-dom';
import InputAdornment from '@mui/material/InputAdornment';

const theme = createTheme();


export default function SignUp() {

    const navigate = useNavigate();
const [name, setName] = useState("")
const [userName, setUserName]= useState("")
const [email, setEmail]= useState("")
const [contact, setContact] = useState("")
const [password, setPassword]= useState("")
const [isError, setIsError] = useState(false);

  const onNameChange = (e) => setName(e.target.value);
  const onUserNameChange = (e) => setUserName(e.target.value);
  const onEmailChange = (e) => setEmail(e.target.value);
  const onPasswordChange = (e) => setPassword(e.target.value);
  const onContactChange = (e) => {
    setContact(e.target.value)
       if(e.target.value.length >10) {
    setIsError(true)
    
  }};

  const handleSubmit = (event) => {
    event.preventDefault();

    const data ={name, email,userName, contact, password}
    commonservice.postAPI('signup',data).then((result=>{
        if(result.data.statusCode===200){
            navigate('/');
        }
        
    }))
  };

  return (
    <ThemeProvider theme={theme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >
          <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Sign Up
          </Typography>
          <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
          <TextField
          onChange={onNameChange}
              margin="normal"
              required
              fullWidth
              id="name"
              label="Name"
              name="name"
              autoComplete="name"
              autoFocus
              value={name}
            />
            <TextField
            onChange={onEmailChange}
              margin="normal"
              required
              fullWidth
              id="email"
              label="Email Address"
              name="email"
              autoComplete="email"
              autoFocus
              value={email}
            />
             <TextField
            onChange={onUserNameChange}
              margin="normal"
              required
              fullWidth
              id="userName"
              label="userName"
              name="userName"
              autoComplete="userName"
              autoFocus
              value={userName}
            />
             <TextField
             onChange={onContactChange}
              margin="normal"
              required
              fullWidth
              id="contact"
              label="Contact Number"
              name="contact"
              autoComplete="contact"
              autoFocus
              value={contact}
              error={isError}
              InputProps={{
                startAdornment: <InputAdornment position="start">
                   +91:
                   </InputAdornment>,
              }}
              
            />
            <TextField
            onChange={onPasswordChange}
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type="password"
              id="password"
              autoComplete="current-password"
              value={password}
            />
            <FormControlLabel
              control={<Checkbox value="remember" color="primary" />}
              label="Remember me"
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign Up
            </Button>
            <Grid container>
              <Grid item>
                <Link href="/" variant="body2">
                  {"Have an account? Sign In"}
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
    </ThemeProvider>
  );
}