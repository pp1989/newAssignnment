import React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';


const theme = createTheme();

export default function Dashboard() {

    return(
        <div>
            
            <ThemeProvider theme={theme}>
            <h1>Welcome to Dashboard!</h1>
            </ThemeProvider>
        </div>
    )
}