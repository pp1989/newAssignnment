import axios from 'axios'

const  API_BASE_URL='http://localhost:3010/api/'

class ApiService {

postAPI(urlSegment, formdata) {  
    const headers = {
        'Content-Type': 'application/json',
        'Application':'text/javascript'

    }

return axios.post(API_BASE_URL+urlSegment,formdata,{ headers: headers})

}
}
export default new ApiService();